#!/usr/bin/sh
appDir=/home/jack/test/sas/
cd $appDir
/sas/home/9.4m5/SASFoundation/9.4/sas  ${appDir}Report.sas

