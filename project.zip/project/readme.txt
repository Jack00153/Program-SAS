Example of automating a SAS process using cron in Linux (centos 8), the SAS script is a report that runs from Monday to Friday at 7 am. Report.sas loads the txt file as a flat file, then the program processes and creates sas7bdat tables with final data. Also for validation test you can use test.sas and then automate it.

Like on the screen.png, you need to set cron and make sure that it is installed and then using the crontab -e command and enter the following:
0 7 * * 1-5 /home/jack/test/sas/script.sh
then save and check using crontab -l command.

programs used:

- SAS 9.4
- crontab
- txt as import file and html to show example

